package main

import (
	"fmt"
	"html/template"
	"log"
	"models"
	"net/http"
	"services"
	"strconv"
)

var tmpls = template.Must(template.ParseGlob("templates/*"))

func home(w http.ResponseWriter, r *http.Request) {
	tmpls.ExecuteTemplate(w, "Home", services.GetAllContacts())
}

func details(w http.ResponseWriter, r *http.Request) {

	cid, _ := strconv.Atoi(r.URL.Query().Get("id"))

	contact, err := services.GetContactById(cid)

	if err != nil {
		http.Error(w, err.Error(), http.StatusNotFound)
	} else {
		tmpls.ExecuteTemplate(w, "Details", contact)
	}
}

func newContact(w http.ResponseWriter, r *http.Request) {
	tmpls.ExecuteTemplate(w, "ContactForm", nil)
}

func addContact(w http.ResponseWriter, r *http.Request) {

	//r.ParseForm()

	contactId, _ := strconv.Atoi(r.FormValue("ContactId"))

	contact := models.Contact{contactId, r.FormValue("FirstName"), r.FormValue("LastName"), r.FormValue("Mobile"), r.FormValue("AlternateMobile"), r.FormValue("MailId")}
	fmt.Println(contact)
	services.AddContact(contact)

	tmpls.ExecuteTemplate(w, "Home", services.GetAllContacts())
}

func main() {
	const port string = ":4545"
	http.HandleFunc("/", home)
	http.HandleFunc("/view", details)
	http.HandleFunc("/new", newContact)
	http.HandleFunc("/add", addContact)
	fmt.Println("Server started at port ", port)
	log.Fatal(http.ListenAndServe(port, nil))
}
