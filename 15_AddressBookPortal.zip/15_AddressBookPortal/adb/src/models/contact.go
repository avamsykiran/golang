package models

type Contact struct {
	ContactId		int
	FirstName       string
	LastName        string
	Mobile          string
	AlternateMobile string
	MailId          string
}
