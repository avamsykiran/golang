package greet

func GreetUser(user string) string{
	return "Hello " + user
}