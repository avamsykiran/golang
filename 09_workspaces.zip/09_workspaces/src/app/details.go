package main

var author string = "Vamsy"
var version string = "1.0.0"
var description string = "a simple project to explain go workspace and packages cocnepts"