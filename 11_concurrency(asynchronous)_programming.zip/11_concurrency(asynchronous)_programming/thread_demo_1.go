package main

import (
	"fmt"
	"time"
)

func main() {
	fmt.Println("This is main")
	time.Sleep(time.Second)
	fmt.Println("Tank you waiting! i have been sleeping for a second")
}
