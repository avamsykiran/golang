package main

import "fmt"

func main(){
	var s1 string
	s1 = "Vamsy"

	s2 := "Kiran"

	fmt.Println(s1 + " " +s2)
}